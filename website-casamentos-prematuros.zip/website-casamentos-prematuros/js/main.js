const b=document.querySelector('.burger'),m=document.getElementById('menu');
b.addEventListener('click',()=>{const o=m.classList.toggle('open');b.setAttribute('aria-expanded',o)});
m.querySelectorAll('a').forEach(a=>a.addEventListener('click',()=>m.classList.remove('open')));
document.querySelectorAll('.flip').forEach(f=>f.addEventListener('click',()=>{
 f.setAttribute('aria-pressed',f.getAttribute('aria-pressed')!=='true')}));
